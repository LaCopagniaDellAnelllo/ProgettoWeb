



import java.sql.*;
import java.util.Scanner;
class Connessione {
	private static Scanner s;
	private static String vino;
	private static String uva;
	private static String data1;
	private static String data2;
	private static String Nome;
	private static String cognome;
	private static String Anno;
	private static String IGP;
	private static int mag;
	private static int can;
	private static int litri;
	private static String idVino;
	private static String idOrdine;
	private static int Cliente_CodiceCliente;
	private static String Cliente_CodiceFiscale;
	private static float prezzo;
	private static int Importo;
	private static int x;
	private static int NBottiglie;
	static Connection connection;
	int op;
	static int i;

	public static void main(String args[]) throws Exception {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			String url = "jdbc:"
					+ "mysql://127.0.0.1:3306/cantina";
			connection = DriverManager.getConnection(url,"root", "alex");
			s = new Scanner(System.in);
			System.out.println("Connessione OK \n");
			int op;
			do{
                System.out.println("Inserire il numero dell'operazione:");
                System.out.println("1)Numero bottiglie presenti in magazzino");
                System.out.println("2)Generalit� di tutti i dipendendi dell azienda");
                System.out.println("3)Individua i dipendenti che lavorano in un determinato magazzino");
                System.out.println("4)Generalita dei clienti e numero bottiglie comprate ");
                System.out.println("5)I dettagli delle 5 bottiglie di vino pi� vecchie in un determinato magazzino");
                System.out.println("6)Numero di bottiglie in ogni magazzino e capacit� del magazzino stesso");
                System.out.println("7)Il nome del vino prodotto con una determinata qualit� d'uva");
                System.out.println("8)Il fatturato dell'azienda");
                System.out.println("9)Il nome e l'indirizzo del magazzino in cui si trova il vino di una determinata annata");
                System.out.println("10)Aggiornare la mansione di un dipende");
                System.out.println("11)Aggiungi una nuova produzione divino");
                System.out.println("12)Inserisci un nuovo Ordine");
                System.out.println("13)Elinina un ordine esistente");
                System.out.println("14)Chiusura Database");			
                op=s.nextInt();				
                switch(op)
                {
                    case 1:
                        System.out.println("Inserisci il nome del vino: \n Lancella \n Alabranno \n Cimmarino \n Terzarulo \n\n ");
                        vino = s.next();
                        caso1(vino);
                        
                        break;
                    case 2:
                        caso2();
                        break;
                    case 3:    
                    	System.out.println("inserisci i numero del magazzino \n 1) Magazzino 1 \n 2) Magazzino 2 \n 3) Magazzino 3");
                    	mag = s.nextInt();
                        caso3(mag);
                        break;
                    case 4:
                        caso4();
                        break;
                    case 5:
                       caso5();
                        break;
                    case 6:
                        caso6();
                        break;
                    case 7:
                    	System.out.println("Inserisci il nome dell' uva: \n Fiano \n Casavecchia \n Pallagrello Bianco \n Pallagrello Nero \n\n ");
                    	uva = s.next();
                        caso7(uva);
                        break;
                    case 8:
                    	System.out.println("inserisci l intervallo di date:");
                    	System.out.println("Inserisci la prima data nel formato aaaa-mm-gg: ");
                    	data1 = s.next();
                    	System.out.println("Inserisci la seconda data nel formato aaaa-mm-gg: ");
                    	data2 = s.next();
                    	caso8(data1,data2);
                    	break;
                    case 9:
                    	System.out.println("Inserisci il nome del vino: ");
                    	Nome = s.next();
                    	System.out.println("inserisci l' annata del vino: ");
                    	Anno = s.next();
                    	caso9(Nome, Anno);
                    	break;
                    case 10:
                    	System.out.println("Insersci il Nome del dipendete a cui aggiornare la mansione:");
                    	Nome= s.next();
                    	System.out.println("Inserire il Cognome del dipendente a cui aggiornare la mansione");
                    	cognome= s.next();
                    	System.out.println("Inserisci l'id dove deve essere inserito");
                    	mag= s.nextInt();
                    	caso10(mag,Nome,cognome);
                    	break;
                    case 11:
                    	System.out.println("Inserisci il nome del vino:");
                    	vino= s.next();
                    	System.out.println("Inserisci l' anno del vino:");
                    	Anno= s.next();
                    	System.out.println("1) IGP Terre del Volturno\n 2) IGP Campania");
                    	int i = s.nextInt();
                    	switch (i) {
                    		case 1:IGP = "Terre del Volturno";
                    		break;
                    		case 2:IGP = "Campania";
                    		break;
                    	}
                    	
                    	System.out.println("Inserisci i litri di vino ");
                    	litri=s.nextInt();
                    	System.out.println("Inserisci la cantina:");
                    	mag=s.nextInt();
                    	System.out.println("Inserisci una di queste tipologia d'uva");
                    	System.out.println(" 1-Fiano Alabranno\n 2-Casavecchia Cimmarino \n 3-Pallagrello Bianco Lancella \n 4-Pallagrello Nero Terzarulo \n\n");
                    	i = s.nextInt();
                    	switch (i) {
                    		case 1:uva = "Fiano";
                    		break;
                    		case 2:uva = "Casavecchio";
                    		break;
                    		case 3:uva = "Pallagrello Bianco";
                    		break;
                    		case 4:uva = "Pallagrello Nero";
                    		break;
                    	}
                    	System.out.println("Inserisci l id del vino :");
                    	System.out.println("\nT1 per il Terzarulo fatto con Pallagrello Nero\n\nL1 per il Lancella fatto con il Pallagrello Bianco\n\nA1 per l'Alabranno fatto con il Finao\n\nC1 per il cimmarino fatto con il Casavecchia\n\n");
                    	idVino=s.next();
                    	System.out.println(idVino);
                    	System.out.println("Inserisci il prezzo alla bottilgia:");
                    	prezzo=s.nextInt();
                    	System.out.println("inserisci il magazzino deve deve essere depositato:");
                    	mag=s.nextInt();
                    	caso11(vino, Anno,IGP,litri, can, uva,idVino, prezzo,mag);
                    	break;
                    case 12:
                    	System.out.println("Qui di seguito verranno chieste informazioni per l'inserimento del nuovo ordine:");
                    	System.out.println("Inserisci l' id dell Ordine");
                    	idOrdine = s.next();
                    	
                    	System.out.println("Inserisci la data nel formato aaaa-mm-gg");
                    	data1 = s.next();
                    	System.out.println("Inserisci il Codice Cliente");
                    	Cliente_CodiceCliente= s.nextInt();
                    	System.out.println("Inserisci il Cliente_CodiceFiscale");
                    	Cliente_CodiceFiscale =s.next();
                    	System.out.println("quante tiplogie di vino ci sono al interno dell ordine?");
                    	x= s.nextInt();
 
                    	caso12(idOrdine, data1, Importo, Cliente_CodiceCliente, Cliente_CodiceFiscale);

                		Importo=0;
                    	i=0;
                    	while (i<x) {
                    		System.out.println("inserisci idVino");
            				idVino=s.next();  
                    		System.out.println("Inserisci il numero di bottiglie:");
            				NBottiglie= s.nextInt();     
            				
                        	switch (idVino) {
                        		case "L1":Importo = Importo+(15*NBottiglie);
                        		caso12c(Importo,idOrdine);

                        		break;
                        		case "A1":Importo = Importo+(14*NBottiglie);
                        		caso12c(Importo,idOrdine);


                        		break;
                        		case "T1":Importo =Importo+ (19*NBottiglie);
                        		caso12c(Importo,idOrdine);


                        		break;
                        		case "C1":Importo =Importo+ (12*NBottiglie);
                        		caso12c(Importo,idOrdine);
                        		
                        		break;
                        	}
            				i++;
            				caso12b(idVino,NBottiglie,idOrdine);
                    		}

        				
                    	
                    	break;
                    case 13:
                    	System.out.println("Elimina un ordine dal database inserisci l'id dell Ordine:");
                    	idOrdine= s.next();
                    	caso13(idOrdine);
                    	break;
                    case 14:
                        System.out.println("connessione chiusa");
                        connection.close();
                        break;
                }
            }while(op!=14);
        }
		catch(Exception e) {
		System.out.println("Connessione Fallita \n");
		System.out.println(e);
		}
		
		
	}
	
	private static void caso1(String vino) {
		
		try {
			String query1="select sum(NBottiglie) from deposita, vino where VinoSfuso_Nome = ? and Vino_idVino=idVino";
			PreparedStatement ps = connection.prepareStatement(query1);
			ps.setString(1, vino);
			ResultSet x = ps.executeQuery();
			
			while (x.next()) {
			String NBottiglie = x.getString("sum(NBottiglie)");
			System.out.printf("\n\n\nIe bottiglie di "+ vino + " in magazzino sono: "+ "%s\n\n\n", NBottiglie );
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private static void caso2() {
		try {
			String query2="select nome, cognome from dipendenti ";
			Statement st = connection.createStatement();
			ResultSet statmant = st.executeQuery(query2);
		    while (statmant.next()){
		        i=1;
		           
		                System.out.print(statmant.getString("nome")+ " " + statmant.getString("cognome") + "\n");
		                i++;
		           		
		    }
		    
		 } 
		catch (SQLException e) {

    }
		
	}
	
	private static void caso3(int mag) {

		try {

			String query3="select dipendenti.Nome  from dipendenti , magazzino  where dipendenti.Magazzino_idMagazzino = ?  ";
			PreparedStatement ps = connection.prepareStatement(query3);
			
			ps.setInt(1, mag);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				String Nome = rs.getString("dipendenti.Nome");
				System.out.printf("\n\n\nIl nome dell dipendente che lvora in magazzino �:\t %s\n\n\n", Nome );
				}
			
		} catch (Exception e) {
			e.printStackTrace();
				
		}
		}
	
	private static void caso4() {
		try {
			String query4="select c.nome, c.cognome,  count(i.NBottiglie) from cliente c, include i";
			Statement st = connection.createStatement();
			ResultSet statmant = st.executeQuery(query4);
			System.out.println("\n\nNome\t\t\tCognome\t\t\t#Bottiglie");
			    while (statmant.next()){
			        i=1;
			           
			                System.out.print(statmant.getString("c.nome")+ "\t\t" + statmant.getString("c.cognome") + "\t\t" +statmant.getString("count(i.Nbottiglie)") + "\n\n");
			                i++;
			           		
			    }
			
		} catch (Exception e) {
		}
	
	}
	
	private static void caso5() {
		try {
			String query5="select v.* from magazzino m, vino v order by v.VinoSfuso_Anno desc limit 5";
			Statement st = connection.createStatement();
			ResultSet statmant = st.executeQuery(query5);
			  System.out.format("\t idVino \t\t\t Centilitri \t\t\t Prezzo \t\t\t VinoSfuso_Nome\t\t\t VinoSfuso_Anno\n");
			    
			    while (statmant.next())
			    {
			        String idVino = statmant.getString("idVino");
			        String Centilitri = statmant.getString("Centilitri");
			        String Prezzo = statmant.getString("Prezzo");
			        String VinoSfuso_Nome = statmant.getString("VinoSfuso_Nome");
			        String VinoSfuso_Anno = statmant.getString("VinoSfuso_Anno");
			        System.out.format("\t %s \t\t\t\t %s \t\t\t\t %s \t\t\t\t %s\t\t\t %s \n",idVino, Centilitri, Prezzo, VinoSfuso_Nome, VinoSfuso_Anno);
			    }
			
		} catch (Exception e) {
			e.printStackTrace();

		}
		
	}
	
	private static void caso6() {
		try {
			String query6="select idMagazzino, M.nome, sum(D.NBottiglie), Capacit� as NBottiglie from magazzino M JOIN deposita D ON M.idMagazzino = D.Magazzino_idMagazzino group by m.nome"; 
			Statement st = connection.createStatement();
			ResultSet statmant = st.executeQuery(query6);
			System.out.println("idMagazzino\tNome\t#bottiglie\tCapacit�");
			   while (statmant.next()){
			        i=1;
			           
			                System.out.print(statmant.getString("idMagazzino")+ " " + statmant.getString("M.nome") + " " +statmant.getString("sum(D.Nbottiglie)") + " " + statmant.getString("Nbottiglie")+ "\n\n");
			                i++;
			           		
			   }
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private static void caso7(String uva) {
		try {
			String query7="select v.Nome from vinosfuso v where v.Qualit�Uva = ?";
			PreparedStatement ps = connection.prepareStatement(query7);
			ps.setString(1,uva );
			ResultSet x = ps.executeQuery();
			
			while (x.next()) {
				String Nome = x.getString("v.nome");
				System.out.printf("\n\n\n Con l'uva di tipo : "+ uva + " si produce il vino: "+ "%s\n\n\n", Nome );
				}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	private static void caso8(String data1, String data2) {
		try {
			String query8="select sum(Importo), sum(NBottiglie) from ordine o join include i on o.idOrdine = i.Ordine_idOrdine where o.data between ? and ?";
			PreparedStatement ps = connection.prepareStatement(query8);
			ps.setString(1,data1 );
			ps.setString(2,data2);
			ResultSet x = ps.executeQuery();
			
			while (x.next()) {
				String Importo = x.getString("sum(Importo)");
				String NBottiglie = x.getString("sum(NBottiglie)");
				System.out.printf("L'importo fatturato dall azienda tra il "+data1+" e il "+data2+" e di %s� e il numero di bottiglie vendute � %s\n\n ",Importo, NBottiglie );
				}
			
		} catch (Exception e) {
			e.printStackTrace();

		}
	
	}
	
	private static void caso9(String Nome, String Anno) {
		try {
			String query9="select m.idMagazzino, m.Nome, m.Via, m.CAP, m.Citt�, v.VinoSfuso_Nome from (magazzino m join deposita  d on  idMagazzino = d.Magazzino_idMagazzino) join vino v on d.Vino_idVino = v.idVino where v.VinoSfuso_Nome = ? and  v.VinoSfuso_Anno = ? ";
			PreparedStatement ps = connection.prepareStatement(query9);
			ps.setString(1,Nome);
			ps.setString(2,Anno);
			ResultSet x = ps.executeQuery();
			
			while (x.next()) {
				System.out.println("il vino "+ x.getString("v.VinoSfuso_Nome") +" si trova nel magazzino " + x.getString("m.idMagazzino") +" di nome "+x.getString("m.Nome") + " a "+x.getString("m.Citt�") +" codice postale � "+x.getString("m.CAP")+"\n\n\n");
			
				}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private static void caso10(int mag, String Nome, String cognome) {
		try {

			System.out.println("Indicare dove deve essere inserito il dipendente: ");
			System.out.println("1)Magazzino");
			System.out.println("2)Cantina");
			PreparedStatement ps = null;
			int op;
			op=s.nextInt();
			
			
			switch (op) {
			case 1:
				String query10a="update dipendenti set Magazzino_idMagazzino = ? , Cantina_idCantina = null where Nome = ? and Cognome = ? ";
				ps = connection.prepareStatement(query10a);
				ps.setInt(1,mag);
				ps.setString(2,Nome);
				ps.setString(3,cognome);
				ps.executeUpdate();
				break;

			case 2:
				String query10b="update dipendenti set dipendenti.Cantina_idCantina = ? , dipendenti.Magazzino_idMagazzino = null where Nome = ? and Cognome = ? ";
				ps= connection.prepareStatement(query10b);
				ps.setInt(1,mag);
				ps.setString(2,Nome);
				ps.setString(3,cognome);
				ps.executeUpdate();
				break;
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private static void caso11(String vino, String Anno,String IGP, int litri,int can, String uva,String idVino,float prezzo,int mag) {
		try {
			String query11="insert into vinosfuso (Nome, Anno, IGP, Litri, Cantina_idCantina, Qualit�Uva) values (?,?,?,?,?,?)";
			PreparedStatement ps =null;
			ps= connection.prepareStatement(query11);
			ps.setString(1,vino);
			ps.setString(2,Anno);
			ps.setInt(3,litri);
			ps.setInt(4,can);
			ps.setString(5,uva);
			ps.executeUpdate();
			
			String query11b="insert into vino (idVino,Centilitri,Prezzo,VinoSfuso_Nome,VinoSfuso_Anno) values(?,75,?,?,?)";
			ps= connection.prepareStatement(query11b);
			ps.setString(1,idVino);
			ps.setFloat(2, prezzo);
			ps.setString(3,vino);
			ps.setString(4,Anno);
			ps.executeUpdate();
			
			String query11c="insert into Deposita (NBottiglie,Magazzino_idMagazzino,Vino_idVino) values(?,?,?)";
			ps= connection.prepareStatement(query11c);
			ps.setInt(1,(int) ((litri*100)/75));
			ps.setInt(2,mag);
			ps.setString(3,idVino );
			ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private static void caso12(String idOrdine, String data1,int Importo, int Cliente_CodiceCliente, String Cliente_CodiceFiscale ) {
		try {
			String query12="insert into ordine (idOrdine, Data, Importo, Cliente_CodiceCliente, Cliente_CodiceFiscale) values (?,?,?,?,?)";
			PreparedStatement ps= connection.prepareStatement(query12);
			ps.setString(1,idOrdine);
			ps.setString(2,data1);
			ps.setInt(3, Importo);
			ps.setInt(4,Cliente_CodiceCliente);
			ps.setString(5,Cliente_CodiceFiscale);
			ps.executeUpdate();
			
		
		} catch (Exception e) {
		}
	}
	private static void caso12b(String idVino, int NBottiglie, String idOrdine) {
		try {
		String query12b ="insert into include(Vino_idVino,Ordine_idOrdine,NBottiglie) values (?,?,?)";
		PreparedStatement ps= connection.prepareStatement(query12b);
		ps.setString(1, idVino);
		ps.setString(2, idOrdine);
		ps.setInt(3, NBottiglie);
		ps.executeUpdate();

		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		}
	private static void caso12c(int Importo, String idOrdine) {
		try {
			String query12c="update ordine set Importo=? where idOrdine = ?";
			PreparedStatement ps= connection.prepareStatement(query12c);
			ps.setInt(1, Importo);
			ps.setString(2, idOrdine);
			ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	private static void caso13(String idOrdine) {
		try {
			String query13b=("delete from include where Ordine_idOrdine =?");
			PreparedStatement ps = connection.prepareStatement(query13b);
			ps.setString(1,idOrdine);
			ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		try {
			String query13=("delete from ordine where idOrdine = ?");
			PreparedStatement ps =null;
			ps= connection.prepareStatement(query13);
			ps.setString(1,idOrdine);
			ps.executeUpdate();
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
}
}
		








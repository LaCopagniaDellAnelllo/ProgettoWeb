import java.sql.*;
public class PrimoJDBC {
public static void main(String[] arg) {
Connection con = null;
try {
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
String url = "jdbc:odbc:Corsi";
con = DriverManager.getConnection(url);
}
catch(Exception e) {
System.out.println("Connessione fallita");
}
try {
Statement query = con.createStatement();
ResultSet result = query.executeQuery(" SELECT * FROM Corsi" );
while(result.next()) {
String nomeCorso = result.getString("NomeCorso");
System.out.println(nomeCorso);
}
}
catch(Exception e) {
System.out.println("Errore nell'interrogazione");
}
}
}